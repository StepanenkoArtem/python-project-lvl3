import requests


def get_web_content(url):
    pass
