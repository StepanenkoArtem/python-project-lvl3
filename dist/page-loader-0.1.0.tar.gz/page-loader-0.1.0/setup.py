# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['page_loader', 'page_loader.scripts']

package_data = \
{'': ['*']}

install_requires = \
['click>=7.0,<8.0', 'requests>=2.22.0,<3.0.0']

entry_points = \
{'console_scripts': ['page_loader = page_loader.scripts.loader:main']}

setup_kwargs = {
    'name': 'page-loader',
    'version': '0.1.0',
    'description': 'Tool for downloding web-pages to local machine',
    'long_description': None,
    'author': 'Artem Stepanenko',
    'author_email': 'artem.stepanenko.ks.ua@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
