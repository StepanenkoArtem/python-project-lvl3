import os


def save_content(page):
    pass
